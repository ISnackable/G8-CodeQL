console.log("------------------------------------");
console.log("middlewares > index.js");
console.log("------------------------------------");
// ------------------------------------------------------
// load modules
// ------------------------------------------------------
// const bodyParser = require("body-parser"); // 'bodyParser' is deprecated.

// ------------------------------------------------------
//  middleware functions
// ------------------------------------------------------
const middleware = {};

module.exports = middleware;
